/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Network;

/**
 *
 * @author mthuan
 */
public class Config {
    public static final String HOST = "127.0.0.1";
    public static final int PORT = 5000;
    public static final int DELAY_TIME = 2000;
    public static final int WIDTH_ROOM = 500;
    public static final int HEIGHT_ROOM = 200;
    public static final int WIDTH_MESSAGE = 500;
    public static final int HEIGHT_MESSAGE = 200;
    public static int LENGTH_KEY = 1024;
    public static int TIME_OTP = 600;
}
